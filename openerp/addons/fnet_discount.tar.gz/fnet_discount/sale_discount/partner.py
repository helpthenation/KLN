from __future__ import division
from openerp.osv import fields, osv
from openerp import models,fields,api,_

class res_partner(models.Model):
    _name='res.partner'
    
    category_discount=fields.Many2one('disc.name','Discount Category')
