import company
import res_config

