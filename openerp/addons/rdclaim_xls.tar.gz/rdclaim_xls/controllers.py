# -*- coding: utf-8 -*-
from openerp import http

# class RdclaimXls(http.Controller):
#     @http.route('/rdclaim_xls/rdclaim_xls/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/rdclaim_xls/rdclaim_xls/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('rdclaim_xls.listing', {
#             'root': '/rdclaim_xls/rdclaim_xls',
#             'objects': http.request.env['rdclaim_xls.rdclaim_xls'].search([]),
#         })

#     @http.route('/rdclaim_xls/rdclaim_xls/objects/<model("rdclaim_xls.rdclaim_xls"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('rdclaim_xls.object', {
#             'object': obj
#         })