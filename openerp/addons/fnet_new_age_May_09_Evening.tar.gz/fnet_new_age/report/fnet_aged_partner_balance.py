# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import time
from openerp.osv import osv
from openerp.report import report_sxw
from common_report_header import common_report_header
from datetime import datetime
from itertools import groupby
import time
from datetime import date
from datetime import datetime
from datetime import timedelta
from dateutil import relativedelta
import itertools
from operator import itemgetter
from dateutil.parser import parse
class fnet_aged_partner_report(report_sxw.rml_parse, common_report_header):

    def __init__(self, cr, uid, name, context):
        super(fnet_aged_partner_report, self).__init__(cr, uid, name, context=context)
        self.total_account = []
        self.localcontext.update({
            'time': time,
            'get_lines': self._get_lines,
            'get_total': self._get_total,
            'get_company': self._get_company,
            'get_currency': self._get_currency,
            'get_account': self._get_account,
            'get_fiscalyear': self._get_fiscalyear,
            'get_target_move': self._get_target_move,
        })

    def set_context(self, objects, data, ids, report_type=None):
        obj_move = self.pool.get('account.move.line')
        ctx = data['form'].get('used_context', {})
        ctx.update({'fiscalyear': False, 'all_fiscalyear': True})
        self.query = obj_move._query_get(self.cr, self.uid, obj='l', context=ctx)
        self.direction_selection = data['form'].get('direction_selection', 'past')
        self.target_move = data['form'].get('target_move', 'all')
        self.date_from = data['form'].get('date_from', time.strftime('%Y-%m-%d'))
        if (data['form']['result_selection'] == 'customer' ):
            self.ACCOUNT_TYPE = ['receivable']
        elif (data['form']['result_selection'] == 'supplier'):
            self.ACCOUNT_TYPE = ['payable']
        else:
            self.ACCOUNT_TYPE = ['payable','receivable']
        self.cr.execute(
            "SELECT a.id " \
            "FROM account_account a " \
            "LEFT JOIN account_account_type t " \
                "ON (a.type=t.code) " \
                'WHERE a.type IN %s' \
                "AND a.active", (tuple(self.ACCOUNT_TYPE), ))
        self.account_ids = [a for (a,) in self.cr.fetchall()]  
        return super(fnet_aged_partner_report, self).set_context(objects, data, ids, report_type=report_type)

    def _get_lines(self, form):
        res = []
        move_state = ['draft','posted']
        if self.target_move == 'posted':
            move_state = ['posted']
        self.cr.execute('SELECT DISTINCT res_partner.id AS id,\
                    res_partner.name AS name \
                FROM res_partner,account_move_line AS l, account_account, account_move am\
                WHERE (l.account_id=account_account.id) \
                    AND (l.move_id=am.id) \
                    AND (am.state IN %s)\
                    AND (account_account.type IN %s)\
                    AND account_account.active\
                    AND ((reconcile_id IS NULL)\
                       OR (reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                    AND (l.partner_id=res_partner.id)\
                    AND (l.date <= %s)\
                    AND ' + self.query + ' \
                ORDER BY res_partner.name', (tuple(move_state), tuple(self.ACCOUNT_TYPE), self.date_from, self.date_from,))
        partners = self.cr.dictfetchall()
        ## mise a 0 du total
        for i in range(7):
            self.total_account.append(0)
        partner_ids=[]
        if form['selection'] == 'sales':
            if len(form['sr_id']) > 1:
                self.cr.execute("""SELECT distinct rp.id, rc.name as branch, 
                                            rp.name as partner,
                                            rp.name as salesperson
                                            FROM account_invoice ai 
                                            JOIN res_partner rp ON (rp.id = ai.partner_id) 
                                            JOIN res_company rc ON (rc.id = ai.company_id)
                                            LEFT JOIN res_users ru ON (ru.id = rp.user_id)
                                            WHERE rp.user_id IN %s """ %(tuple(form['sr_id']),))
                sale_person=self.cr.dictfetchall()
                selected_partner_ids = [x['id'] for x in sale_person]
            elif len(form['sr_id']) == 1:
                self.cr.execute("""SELECT distinct rp.id, rc.name as branch, 
                                            rp.name as partner,
                                            rp.name as salesperson
                                            FROM account_invoice ai 
                                            JOIN res_partner rp ON (rp.id = ai.partner_id) 
                                            JOIN res_company rc ON (rc.id = ai.company_id)
                                            LEFT JOIN res_users ru ON (ru.id = rp.user_id)
                                            WHERE rp.user_id = %s """ %(form['sr_id'][0]))
                sale_person=self.cr.dictfetchall()
                selected_partner_ids = [x['id'] for x in sale_person]
        elif form['selection'] == 'executive':
            selected_partner_ids = form['stockiest_ids']       
        elif form['selection'] == 'team':                
            if len(form['manager_id']) > 1:
                self.cr.execute("""SELECT distinct rp.id, rc.name as branch,
                                            rp.name as partner,
                                            rp.name as salesperson
                                            FROM account_invoice ai 
                                            JOIN res_partner rp ON (rp.id = ai.partner_id) 
                                            JOIN res_company rc ON (rc.id = ai.company_id)
                                            JOIN crm_case_section css ON (css.id = rp.section_id) JOIN res_users ru ON (ru.id = css.user_id)
                                            WHERE css.user_id IN %s """%(tuple(form['manager_id']),))
                sale_person=self.cr.dictfetchall()  
                selected_partner_ids = [x['id'] for x in sale_person]
            elif len(form['manager_id']) == 1:
                self.cr.execute("""SELECT distinct rp.id, rc.name as branch,
                                            rp.name as partner,
                                            rp.name as salesperson
                                            FROM account_invoice ai 
                                            JOIN res_partner rp ON (rp.id = ai.partner_id) 
                                            JOIN res_company rc ON (rc.id = ai.company_id)
                                            JOIN crm_case_section css ON (css.id = rp.section_id) JOIN res_users ru ON (ru.id = css.user_id)
                                            WHERE css.user_id = %s """%(form['manager_id'][0]))
                sale_person=self.cr.dictfetchall()  
                selected_partner_ids = [x['id'] for x in sale_person]
                
        elif form['selection']=='all':
            selected_partner_ids=[x['id'] for x in partners]
                                    
        for x in partners:
             if x['id'] in selected_partner_ids:
                 partner_ids.append(x['id'])
        #~ partner_ids = [x['id'] for x in partners]
        if not partner_ids:
            return []

        info=[] 
        #~ totals = {}
        #~ self.cr.execute('SELECT l.partner_id, l.debit,l.credit, l.ref\
                    #~ FROM account_move_line AS l, account_account, account_move am \
                    #~ WHERE (l.account_id = account_account.id) AND (l.move_id=am.id) \
                    #~ AND (am.state IN %s)\
                    #~ AND (account_account.type IN %s)\
                    #~ AND (l.partner_id IN %s)\
                    #~ AND ((l.reconcile_id IS NULL)\
                    #~ OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                    #~ AND ' + self.query + '\
                    #~ AND account_account.active\
                    #~ AND (l.date <= %s)\
                    #~ GROUP BY l.partner_id ,l.ref, l.debit,l.credit', (tuple(move_state), tuple(self.ACCOUNT_TYPE), tuple(partner_ids), self.date_from, self.date_from,))
        #~ t = self.cr.fetchall()
        #~ print 't111111111111111tttttttttttttttttttttttttttttttt',t
        #~ for i in t:
            #~ totals[i[0]] = i[1]

        # This dictionary will store the future or past of all partners
        future_past = {}
        if self.direction_selection == 'future':
            self.cr.execute('SELECT l.partner_id,SUM(l.debit-l.credit) ,l.reconcile_partial_id, l.date,aj.code,l.ref\
                        FROM account_move_line AS l, account_account, account_move am \
                        JOIN account_journal AS aj ON(aj.id=am.journal_id)\
                        WHERE (l.account_id=account_account.id) AND (l.move_id=am.id) \
                        AND (am.state IN %s)\
                        AND (account_account.type IN %s)\
                        AND (COALESCE(l.date_maturity, l.date) < %s)\
                        AND (l.partner_id IN %s)\
                        AND ((l.reconcile_id IS NULL)\
                        OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                        AND '+ self.query + '\
                        AND account_account.active\
                    AND (l.date <= %s)\
                        GROUP BY l.partner_id, l.reconcile_partial_id,l.ref,aj.code,l.date', (tuple(move_state), tuple(self.ACCOUNT_TYPE), self.date_from, tuple(partner_ids),self.date_from, self.date_from,))
            t = self.cr.fetchall()
            #~ print'TTTTTTTTTTTTTTTTTTTTTTTT',t
            for i in t:
                info.append({'partner_id':i[0],'code':i[4],'dates':i[3],'amt':i[1],'journal':i[5]})
                future_past[i[0]] = i[1]
                
        elif self.direction_selection == 'past': # Using elif so people could extend without this breaking
            self.cr.execute('SELECT l.partner_id, SUM(l.debit-l.credit) ,l.reconcile_partial_id, l.date,aj.code,l.ref\
                    FROM account_move_line AS l, account_account, account_move am \
                    JOIN account_journal AS aj ON(aj.id=am.journal_id)\
                    WHERE (l.account_id=account_account.id) AND (l.move_id=am.id)\
                        AND (am.state IN %s)\
                        AND (account_account.type IN %s)\
                        AND (COALESCE(l.date_maturity,l.date) > %s)\
                        AND (l.partner_id IN %s)\
                        AND ((l.reconcile_id IS NULL)\
                        OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s  AND not recon.opening_reconciliation)))\
                        AND '+ self.query + '\
                        AND account_account.active\
                    AND (l.date <= %s )\
                        GROUP BY l.partner_id, l.reconcile_partial_id,l.ref,aj.code,l.date', (tuple(move_state), tuple(self.ACCOUNT_TYPE), self.date_from, tuple(partner_ids), self.date_from, self.date_from,))
            t = self.cr.fetchall()
            for i in t:
                info.append({'partner_id':i[0],'code':i[4],'dates':i[3],'amt':i[1],'journal':i[5]})
                future_past[i[0]] = i[1]
        history = []       
        another=[]
        for j in range(6):
            args_list = (tuple(move_state), tuple(self.ACCOUNT_TYPE), tuple(partner_ids),self.date_from,)
            dates_query = '(COALESCE(l.date_maturity,l.date)'
            if form[str(j)]['start'] and form[str(j)]['stop']:
                dates_query += ' BETWEEN %s AND %s)'
                args_list += (form[str(j)]['start'], form[str(j)]['stop'])
            elif form[str(j)]['start']:
                dates_query += ' >= %s)'
                args_list += (form[str(j)]['start'],)
            else:
                dates_query += ' <= %s)'
                args_list += (form[str(j)]['stop'],)
            args_list += (self.date_from,)
            self.cr.execute('''SELECT l.partner_id,SUM(l.debit-l.credit) ,l.reconcile_partial_id, l.date,aj.code,l.ref
                    FROM account_move_line AS l, account_account, account_move am 
                    JOIN account_journal AS aj ON(aj.id=am.journal_id)
                    WHERE (l.account_id = account_account.id) AND (l.move_id=am.id)
                        AND (am.state IN %s)
                        AND (account_account.type IN %s)
                        AND (l.partner_id IN %s)
                        AND ((l.reconcile_id IS NULL)
                          OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))
                        AND ''' + self.query + '''
                        AND account_account.active
                        AND ''' + dates_query + '''
                    AND (l.date <= %s)
                    GROUP BY l.partner_id, l.reconcile_partial_id,l.ref,aj.code,l.date''', args_list)
            partners_partial = self.cr.fetchall()
            partners_amount = dict((i[0],0) for i in partners_partial)
            partnerID=list(i[0] for i in partners_partial)
            chk=[]
            u=[]
            for partner_info in partners_partial:
                if partner_info[2]:
                    # in case of partial reconciliation, we want to keep the left amount in the oldest period
                    self.cr.execute('''SELECT MIN(COALESCE(date_maturity,date)) FROM account_move_line WHERE reconcile_partial_id = %s''', (partner_info[2],))
                    date = self.cr.fetchall()
                    partial = False
                    if 'BETWEEN' in dates_query:
                        partial = date and args_list[-3] <= date[0][0] <= args_list[-2]
                    elif '>=' in dates_query:
                        partial = date and date[0][0] >= form[str(j)]['start']
                    else:
                        partial = date and date[0][0] <= form[str(j)]['stop']
                    if partial:
                        # partial reconcilation
                        limit_date = 'COALESCE(l.date_maturity,l.date) %s %%s' % ('<=' if self.direction_selection == 'past' else '>=',)
                        self.cr.execute('''SELECT l.partner_id,(l.debit-l.credit)
                                           FROM account_move_line AS l, account_move AS am
                                           WHERE l.move_id = am.id AND am.state in %s
                                           AND l.reconcile_partial_id = %s
                                           AND ''' + limit_date, (tuple(move_state), partner_info[2], self.date_from))                                           
                        unreconciled_amount = self.cr.fetchall()
                        self.cr.execute('''SELECT l.partner_id as id ,aj.code as code ,ai.date_invoice as date,(l.debit-l.credit) as amount,l.ref as journal
                                           FROM account_move_line AS l, account_move AS am
                                           JOIN account_journal AS aj ON(aj.id=am.journal_id)
                                           JOIN account_invoice as ai ON (ai.move_id=am.id)
                                           WHERE l.move_id = am.id AND am.state in %s
                                           AND l.reconcile_partial_id = %s
                                           AND ''' + limit_date, (tuple(move_state), partner_info[2], self.date_from))
                        amount = self.cr.dictfetchall()
                        if amount == [] and unreconciled_amount != []:    
                            data = sorted(unreconciled_amount, key=itemgetter(0))   
                            a = {k: list(v) for k, v in groupby(data, key=itemgetter(0))}                    
                            tet=[]
                            count=0.0
                            for i in unreconciled_amount:
                                count+=i[1]
                            for i in info:                                  
                                  if a.has_key(i['partner_id']):
                                      for k in a[i['partner_id']]:
                                          tet=i  
                            if tet != []:                                 
                               tet['amt']=tet['amt']+count 
                               if tet['code'] == 'SAJ':
                                   info.append(tet)
                        if amount != []:
                            cnt=0.0
                            for i in unreconciled_amount:
                                cnt+=i[1]
                            amount[0]['amount']= cnt
                            if amount[0]['code'] == 'SAJ':
                                info.append({'partner_id':amount[0]['id'],'code':amount[0]['code'],'dates':amount[0]['date'],'amt':amount[0]['amount'],'journal':amount[0]['journal']})
                        partners_amount[partner_info[0]] += unreconciled_amount[0][0]
                else:                    
                    partners_amount[partner_info[0]] += partner_info[1]
                    if partner_info[4]=='SAJ':
                        info.append({'partner_id':partner_info[0],'code':partner_info[4],'dates':partner_info[3],'amt':partner_info[1],'journal':partner_info[5]})
                    else:
                        u.append(partner_info[1])
                        get=[]
                        for i in info:
                              if i['partner_id'] == partner_info[0]:
                                  get=i
                        if get != []:
                            get['amt']=get['amt']+partner_info[1]
                            if get['code'] == 'SAJ':
                                info.append(get)

        for i in info:
            #~ print'************************************************',i
            if i['code'] == 'SAJ':
                  TODAY = datetime.strptime(self.date_from, '%Y-%m-%d')
                  dat=parse(i['dates'])
                  DAY = datetime.strptime(str(dat), '%Y-%m-%d %H:%M:%S')
                  AGE=DAY - TODAY  
                  i['dates']=DAY.strftime('%d-%m-%Y')
                  i.update({'age':abs(AGE.days)+1})
            else:
                 info.remove(i)
        seen = set()
        new_l = []
        for d in info:
            t = tuple(d.items())
            if t not in seen:
                seen.add(t)
                new_l.append(d)
        journal_list=[]
        for i in new_l:
              journal_list.append(i['journal'])
        journal=list(set(journal_list))

        g={}
        new_g=[]
        lols=sorted(new_l,key=itemgetter('journal'))
        for key,value in itertools.groupby(lols,key=itemgetter('journal')):
            for i in value:
                 g.setdefault(key, []).append(i)
        for i in journal:
            if len(g.get(i)) == 1:
                new_g.append(g.get(i)[0])
            elif  len(g.get(i)) > 1:
                k=[]
                k.append(g.get(i)[0])
                amount=[]
                for h in g.get(i):
                    amount.append(h['amt'])
                k[0]['amt']=min(amount)   
                new_g.append(k[0])
        v={}
        lolsss=sorted(new_g,key=itemgetter('partner_id'))
        for key,value in itertools.groupby(lolsss,key=itemgetter('partner_id')):
            for i in value:
                 v.setdefault(key, []).append(i)
        #~ print'vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv',v
        l1=form['1']['name'].split('-')
        l2=form['2']['name'].split('-')
        l3=form['3']['name'].split('-')        
        l4=form['4']['name'].split('-')        
        l5=form['5']['name'].split('-')
        for key,value in v.iteritems():
              for i in value:
                   #~ print'****************************************',i
                   if i.has_key('age'):
                       if int(l5[0]) <=  i['age'] <= int(l5[1]):
                           i.update({'0':0.0,'1':0.0,'2':0.0,'3':0.0,'4':0.0,'5':i['amt']})               
                       elif int(l4[0]) <=  i['age'] <= int(l4[1]):
                           i.update({'0':0.0,'1':0.0,'2':0.0,'3':0.0,'4':i['amt'],'5':0.0})
                       elif int(l3[0]) <= i['age'] <= int(l3[1]):
                           i.update({'0':0.0,'1':0.0,'2':0.0,'3':i['amt'],'4':0.0,'5':0.0})
                       elif int(l2[0]) <=  i['age'] <= int(l2[1]):
                           i.update({'0':0.0,'1':0.0,'2':i['amt'],'3':0.0,'4':0.0,'5':0.0})
                       elif int(l1[0]) <= i['age'] <= int(l1[1]):
                           i.update({'0':0.0,'1':i['amt'],'2':0.0,'3':0.0,'4':0.0,'5':0.0})
                       else:  
                           i.update({'0':i['amt'],'1':0.0,'2':0.0,'3':0.0,'4':0.0,'5':0.0})
                   else:
                          TODAY = datetime.strptime(self.date_from, '%Y-%m-%d')
                          dat=parse(i['dates'])
                          DAY = datetime.strptime(str(dat), '%Y-%m-%d %H:%M:%S')
                          AGE=DAY - TODAY  
                          i['dates']=DAY.strftime('%d-%m-%Y')
                          i.update({'age':abs(AGE.days)+1})
                          if int(l5[0]) <=  i['age'] <= int(l5[1]):
                               i.update({'0':0.0,'1':0.0,'2':0.0,'3':0.0,'4':0.0,'5':i['amt']})               
                          elif int(l4[0]) <=  i['age'] <= int(l4[1]):
                               i.update({'0':0.0,'1':0.0,'2':0.0,'3':0.0,'4':i['amt'],'5':0.0})
                          elif int(l3[0]) <= i['age'] <= int(l3[1]):
                               i.update({'0':0.0,'1':0.0,'2':0.0,'3':i['amt'],'4':0.0,'5':0.0})
                          elif int(l2[0]) <=  i['age'] <= int(l2[1]):
                               i.update({'0':0.0,'1':0.0,'2':i['amt'],'3':0.0,'4':0.0,'5':0.0})
                          elif int(l1[0]) <= i['age'] <= int(l1[1]):
                               i.update({'0':0.0,'1':i['amt'],'2':0.0,'3':0.0,'4':0.0,'5':0.0})
                          else:  
                               i.update({'0':i['amt'],'1':0.0,'2':0.0,'3':0.0,'4':0.0,'5':0.0})
                               
        for key,value in v.iteritems():
            ad=[]
            for val in value:
                ad.append(val['amt'])
            v[key].append({'total':sum(ad)})
        result=[]
        for partner in partners:
              values={}
              if v.has_key(partner['id']):   
                  values['name'] = partner['name']  
                  get_total=v[partner['id']].pop()
                  values['total']=get_total['total']
                  #~ sorted(rd_tm, key=lambda k: k['product_id'])
                  #~ g=sorted(v[partner['id']], key=lambda k: k['dates'])
                  #~ print'GGGGGGGGGGGGGGGGG',g
                  values['details'] =  v[partner['id']]
              result.append(values)   
        final=[]
        if form['selection'] == 'sales':
                for k in form['sr_id']:
                    self.cr.execute("""SELECT distinct rp.id as id,rp.name
                                                FROM account_invoice ai 
                                                JOIN res_partner rp ON (rp.id = ai.partner_id) 
                                                JOIN res_company rc ON (rc.id = ai.company_id)
                                                LEFT JOIN res_users ru ON (ru.id = rp.user_id)
                                                WHERE rp.user_id = %s """ %(k))
                    person=self.cr.dictfetchall()
                    person_ids = [x['name'] for x in person]
                    self.cr.execute("""select name,city from res_partner join res_users on res_users.partner_id=res_partner.id where res_users.id=%d"""%(k))
                    s=self.cr.fetchone()
                    final.append({s:person_ids})

        elif form['selection'] == 'team':
            for k in form['manager_id']:
                    self.cr.execute("""SELECT distinct rp.id, rc.name as branch,
                                            rp.name as name,
                                            rp.name as salesperson
                                            FROM account_invoice ai 
                                            JOIN res_partner rp ON (rp.id = ai.partner_id) 
                                            JOIN res_company rc ON (rc.id = ai.company_id)
                                            JOIN crm_case_section css ON (css.id = rp.section_id) JOIN res_users ru ON (ru.id = css.user_id)
                                            WHERE css.user_id = %s """%(k))
                    person=self.cr.dictfetchall()
                    person_ids = [x['name'] for x in person]
                    self.cr.execute("""select name,city from res_partner join res_users on res_users.partner_id=res_partner.id where res_users.id=%d"""%(k))
                    s=self.cr.fetchone()
                    final.append({s:person_ids})
        done=[]
        res=[]
        for r in result:
            if r != {}:
                res.append(r)
        for k in final:
              for key,value in k.iteritems():
                    f=[]
                    for v in res:
                          if v['name'] in value:
                              f.append(v)
                    if f != []:
                        done.append({'person':key[0],'customer':f}) 
        if form['selection'] == 'sales':
            return done
        elif form['selection'] == 'team':
            return done
        elif form['selection'] == 'all':        
            return res
        elif form['selection'] == 'executive':      
            return res             


    def _get_total(self,form):
        h=self._get_lines(form)
        five=[]
        four=[]
        three=[]
        two=[]
        one=[]
        zero=[]
        tot=[]
        for i in h:
             if i.has_key('customer'):
                for key,value in i.iteritems():
                     for val in value:
                           if type(val) == dict:
                                for amt in  val['details']:
                                    five.append(amt['5'])
                                    four.append(amt['4'])
                                    three.append(amt['3'])
                                    two.append(amt['2'])
                                    one.append(amt['1'])
                                    zero.append(amt['0'])
                                    
             else:
                 for key,value in i.iteritems():
                     if type(value) == list:
                         for amt in value:
                                five.append(amt['5'])
                                four.append(amt['4'])
                                three.append(amt['3'])
                                two.append(amt['2'])
                                one.append(amt['1'])
                                zero.append(amt['0'])                                             
        res=[]
        values={}
        values['zero']=sum(zero)
        values['one']=sum(one)
        values['two']=sum(two)
        values['three']=sum(three)
        values['four']=sum(four)
        values['five']=sum(five)
        values['total']=  sum(zero) +  sum(one) + sum(two) +  sum(three) + sum(four) + sum(five)
        res.append(values)       
        #~ period = self.total_account[int(pos)]
        return res
class report_fnetagedpartnerbalance(osv.AbstractModel):
    _name = 'report.fnet_new_age.report_fnetagedpartnerbalance'
    _inherit = 'report.abstract_report'
    _template = 'fnet_new_age.report_fnetagedpartnerbalance'
    _wrapped_report_class = fnet_aged_partner_report

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
