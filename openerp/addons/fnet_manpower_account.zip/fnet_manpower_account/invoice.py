# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-today OpenERP SA (<http://www.openerp.com>)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.osv import osv, fields

class account_move_line(osv.osv):
    _inherit="account.move.line"
    _columns= {
    
        'bill_no':fields.char('Bill No'),
    }
    
class account_move(osv.osv):
    _inherit="account.move"
    _columns= {
    
        'paid_to':fields.char('Paid To'),
        'bvp_no':fields.char('BPV No'),
        'vendor_code':fields.char('Vendor Code'),
        
    }

class account_voucher(osv.osv):
    _inherit="account.voucher"
    _columns= {
    
        'bvp_no':fields.char('BPV No'),
        'vendor_code':fields.char('Vendor Code'),
        
    }
    
    def button_proforma_voucher(self, cr, uid, ids, context=None):
        if context.get('invoice_type')=='out_invoice':
            account_val=self.pool.get('account.move.line')
            account_id=account_val.search(cr,uid,[('invoice','=',context.get('invoice_id'))],context=context)
            account_rec=account_val.browse(cr,uid,account_id,context=context)
            sale_val=self.pool.get('sale.order')
            for rec in account_rec:
                sale_id=sale_val.search(cr,uid,[('name','=',rec.invoice.origin)])
                sale_rec=sale_val.browse(cr,uid,sale_id,context=context)
                account_val.write(cr, uid, rec.id, {'job_id': sale_rec.id}, context=context)         
            new_id = super(account_voucher, self).button_proforma_voucher(cr, uid,ids, context=context)
