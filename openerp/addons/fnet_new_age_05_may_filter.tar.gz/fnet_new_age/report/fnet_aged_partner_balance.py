# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import time
from openerp.osv import osv
from openerp.report import report_sxw
from common_report_header import common_report_header
from datetime import datetime
from itertools import groupby
from operator import itemgetter
import time
from datetime import date
from datetime import datetime
from datetime import timedelta
from dateutil import relativedelta
import itertools
from operator import itemgetter
class fnet_aged_partner_report(report_sxw.rml_parse, common_report_header):

    def __init__(self, cr, uid, name, context):
        super(fnet_aged_partner_report, self).__init__(cr, uid, name, context=context)
        self.total_account = []
        self.localcontext.update({
            'time': time,
            'get_lines_with_out_partner': self._get_lines_with_out_partner,
            'get_lines': self._get_lines,
            'get_total': self._get_total,
            'get_direction': self._get_direction,
            'get_for_period': self._get_for_period,
            'get_company': self._get_company,
            'get_currency': self._get_currency,
            'get_partners':self._get_partners,
            'get_account': self._get_account,
            'get_fiscalyear': self._get_fiscalyear,
            'get_target_move': self._get_target_move,
        })

    def set_context(self, objects, data, ids, report_type=None):
        obj_move = self.pool.get('account.move.line')
        ctx = data['form'].get('used_context', {})
        ctx.update({'fiscalyear': False, 'all_fiscalyear': True})
        self.query = obj_move._query_get(self.cr, self.uid, obj='l', context=ctx)
        self.direction_selection = data['form'].get('direction_selection', 'past')
        self.target_move = data['form'].get('target_move', 'all')
        self.date_from = data['form'].get('date_from', time.strftime('%Y-%m-%d'))
        if (data['form']['result_selection'] == 'customer' ):
            self.ACCOUNT_TYPE = ['receivable']
        elif (data['form']['result_selection'] == 'supplier'):
            self.ACCOUNT_TYPE = ['payable']
        else:
            self.ACCOUNT_TYPE = ['payable','receivable']
        return super(fnet_aged_partner_report, self).set_context(objects, data, ids, report_type=report_type)

    def _get_lines(self, form):
        print'FORMMMMMMMMMMMMMMMMMMMMMMM',form['sr_id']
        res = []
        move_state = ['draft','posted']
        #~ where_sql=[]
#~ 
#~ 
        #~ 
            #~ where_sql.append("JOIN crm_case_section css ON (css.id = res_partner.section_id) JOIN res_users ru ON (ru.id = css.user_id)")
        #~ if len(where_sql) < 1:
            #~ where_sql=''
        #~ print where_sql,'*********'
        if self.target_move == 'posted':
            move_state = ['posted']
        self.cr.execute('SELECT DISTINCT res_partner.id AS id,\
                    res_partner.name AS name \
                FROM res_partner,account_move_line AS l, account_account, account_move am\
                WHERE (l.account_id=account_account.id) \
                    AND (l.move_id=am.id) \
                    AND (am.state IN %s)\
                    AND (account_account.type IN %s)\
                    AND account_account.active\
                    AND ((reconcile_id IS NULL)\
                       OR (reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                    AND (l.partner_id=res_partner.id)\
                    AND (l.date <= %s)\
                    AND ' + self.query + ' \
                ORDER BY res_partner.name', (tuple(move_state), tuple(self.ACCOUNT_TYPE), self.date_from, self.date_from,))
        partners = self.cr.dictfetchall()
        print'PARTNERRRRRRRRRRRRRRRRRRRRRRRRRRRRR',partners
        ## mise a 0 du total
        for i in range(7):
            self.total_account.append(0)
            print self.total_account.append(0)
        #
        # Build a string like (1,2,3) for easy use in SQL query
        partner_ids=[]
        if form['selection'] == 'sales':
            if len(form['sr_id']) > 1:
                self.cr.execute("""SELECT distinct rp.id, rc.name as branch, 
                                            rp.name as partner,
                                            rp.name as salesperson
                                            FROM account_invoice ai 
                                            JOIN res_partner rp ON (rp.id = ai.partner_id) 
                                            JOIN res_company rc ON (rc.id = ai.company_id)
                                            LEFT JOIN res_users ru ON (ru.id = rp.user_id)
                                            WHERE rp.user_id IN %s """ %(tuple(form['sr_id']),))
                sale_person=self.cr.dictfetchall()
                print'SALEEEEEEEEEEEEEEEEEE',sale_person
                selected_partner_ids = [x['id'] for x in sale_person]
            elif len(form['sr_id']) == 1:
                self.cr.execute("""SELECT distinct rp.id, rc.name as branch, 
                                            rp.name as partner,
                                            rp.name as salesperson
                                            FROM account_invoice ai 
                                            JOIN res_partner rp ON (rp.id = ai.partner_id) 
                                            JOIN res_company rc ON (rc.id = ai.company_id)
                                            LEFT JOIN res_users ru ON (ru.id = rp.user_id)
                                            WHERE rp.user_id = %s """ %(form['sr_id'][0]))
                sale_person=self.cr.dictfetchall()
                print'SALEEEEEEEEEEEEEEEEEE',sale_person
                selected_partner_ids = [x['id'] for x in sale_person]
        elif form['selection'] == 'executive':
            selected_partner_ids = form['stockiest_ids']       
        elif form['selection'] == 'team':                
            if len(form['manager_id']) > 1:
                self.cr.execute("""SELECT distinct rp.id, rc.name as branch,
                                            rp.name as partner,
                                            rp.name as salesperson
                                            FROM account_invoice ai 
                                            JOIN res_partner rp ON (rp.id = ai.partner_id) 
                                            JOIN res_company rc ON (rc.id = ai.company_id)
                                            JOIN crm_case_section css ON (css.id = rp.section_id) JOIN res_users ru ON (ru.id = css.user_id)
                                            WHERE rp.section_id IN %s """%(tuple(form['manager_id']),))
                sale_person=self.cr.dictfetchall()  
                selected_partner_ids = [x['id'] for x in sale_person]
            elif len(form['manager_id']) == 1:
                self.cr.execute("""SELECT distinct rp.id, rc.name as branch,
                                            rp.name as partner,
                                            rp.name as salesperson
                                            FROM account_invoice ai 
                                            JOIN res_partner rp ON (rp.id = ai.partner_id) 
                                            JOIN res_company rc ON (rc.id = ai.company_id)
                                            JOIN crm_case_section css ON (css.id = rp.section_id) JOIN res_users ru ON (ru.id = css.user_id)
                                            WHERE rp.section_id = %s """%(form['manager_id'][0]))
                sale_person=self.cr.dictfetchall()  
                selected_partner_ids = [x['id'] for x in sale_person]
                
        else:
            selected_partner_ids=[x['id'] for x in partners]
                                    
        for x in partners:
             if x['id'] in selected_partner_ids:
                 print x['name']
                 partner_ids.append(x['id'])
        #~ partner_ids = [x['id'] for x in partners]
        print'PARTNERRRRRRRRRIDS',partner_ids
        if not partner_ids:
            return []
        # This dictionary will store the debit-credit for all partners, using partner_id as key.
        info=[] 
        totals = {}
        self.cr.execute('SELECT l.partner_id, l.debit,l.credit, l.ref\
                    FROM account_move_line AS l, account_account, account_move am \
                    WHERE (l.account_id = account_account.id) AND (l.move_id=am.id) \
                    AND (am.state IN %s)\
                    AND (account_account.type IN %s)\
                    AND (l.partner_id IN %s)\
                    AND ((l.reconcile_id IS NULL)\
                    OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                    AND ' + self.query + '\
                    AND account_account.active\
                    AND (l.date <= %s)\
                    GROUP BY l.partner_id ,l.ref, l.debit,l.credit', (tuple(move_state), tuple(self.ACCOUNT_TYPE), tuple(partner_ids), self.date_from, self.date_from,))
        t = self.cr.fetchall()
        for i in t:
            totals[i[0]] = i[1]

        # This dictionary will store the future or past of all partners
        future_past = {}
        if self.direction_selection == 'future':
            self.cr.execute('SELECT l.partner_id,SUM(l.debit-l.credit) ,l.reconcile_partial_id, l.date,aj.code,l.ref\
                        FROM account_move_line AS l, account_account, account_move am \
                        JOIN account_journal AS aj ON(aj.id=am.journal_id)\
                        WHERE (l.account_id=account_account.id) AND (l.move_id=am.id) \
                        AND (am.state IN %s)\
                        AND (account_account.type IN %s)\
                        AND (COALESCE(l.date_maturity, l.date) < %s)\
                        AND (l.partner_id IN %s)\
                        AND ((l.reconcile_id IS NULL)\
                        OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                        AND '+ self.query + '\
                        AND account_account.active\
                    AND (l.date <= %s)\
                        GROUP BY l.partner_id, l.reconcile_partial_id,l.ref,aj.code,l.date', (tuple(move_state), tuple(self.ACCOUNT_TYPE), self.date_from, tuple(partner_ids),self.date_from, self.date_from,))
            t = self.cr.fetchall()
            print'FUTUREttttttttttttttttttttttttttttt',t
            for i in t:
                h=(i[0],i[4],i[3],i[1],i[5])
                info.append([h])
                future_past[i[0]] = i[1]
                
        elif self.direction_selection == 'past': # Using elif so people could extend without this breaking
            self.cr.execute('SELECT l.partner_id,SUM(l.debit-l.credit) ,l.reconcile_partial_id, l.date,aj.code,l.ref \
                    FROM account_move_line AS l, account_account, account_move am \
                    JOIN account_journal AS aj ON(aj.id=am.journal_id)\
                    WHERE (l.account_id=account_account.id) AND (l.move_id=am.id)\
                        AND (am.state IN %s)\
                        AND (account_account.type IN %s)\
                        AND (COALESCE(l.date_maturity,l.date) > %s)\
                        AND (l.partner_id IN %s)\
                        AND ((l.reconcile_id IS NULL)\
                        OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s  AND not recon.opening_reconciliation)))\
                        AND '+ self.query + '\
                        AND account_account.active\
                    AND (l.date <= %s)\
                        GROUP BY l.partner_id, l.reconcile_partial_id,l.ref,aj.code,l.date', (tuple(move_state), tuple(self.ACCOUNT_TYPE), self.date_from, tuple(partner_ids), self.date_from, self.date_from,))
            t = self.cr.fetchall()
            print'PASTTTTTTTTTTTTT',t
            for i in t:
                future_past[i[0]] = i[1]
                #~ h=(j[0],j[4],j[3],sum(add),j[5]) /HERRRRRRRRRRRRR
                print i
        # Use one query per period and store results in history (a list variable)
        # Each history will contain: history[1] = {'<partner_id>': <partner_debit-credit>}
        history = []       
        another=[]
        for i in range(5):
            args_list = (tuple(move_state), tuple(self.ACCOUNT_TYPE), tuple(partner_ids),self.date_from,)
            dates_query = '(COALESCE(l.date_maturity,l.date)'
            if form[str(i)]['start'] and form[str(i)]['stop']:
                dates_query += ' BETWEEN %s AND %s)'
                args_list += (form[str(i)]['start'], form[str(i)]['stop'])
            elif form[str(i)]['start']:
                dates_query += ' >= %s)'
                args_list += (form[str(i)]['start'],)
            else:
                dates_query += ' <= %s)'
                args_list += (form[str(i)]['stop'],)
            args_list += (self.date_from,)
            self.cr.execute('''SELECT l.partner_id,SUM(l.debit-l.credit) ,l.reconcile_partial_id, l.date,aj.code,l.ref
                    FROM account_move_line AS l, account_account, account_move am 
                    JOIN account_journal AS aj ON(aj.id=am.journal_id)
                    WHERE (l.account_id = account_account.id) AND (l.move_id=am.id)
                        AND (am.state IN %s)
                        AND (account_account.type IN %s)
                        AND (l.partner_id IN %s)
                        AND ((l.reconcile_id IS NULL)
                          OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))
                        AND ''' + self.query + '''
                        AND account_account.active
                        AND ''' + dates_query + '''
                    AND (l.date <= %s)
                    GROUP BY l.partner_id, l.reconcile_partial_id,l.ref,aj.code,l.date''', args_list)
            partners_partial = self.cr.fetchall()
            print'partners_partial',partners_partial
            another.append(partners_partial)
            partners_amount = dict((i[0],0) for i in partners_partial)
            partnerID=list(i[0] for i in partners_partial)
            
            for partner_info in partners_partial:
                print partner_info[0]
                if partner_info[2]:
                    # in case of partial reconciliation, we want to keep the left amount in the oldest period
                    self.cr.execute('''SELECT MIN(COALESCE(date_maturity,date)) FROM account_move_line WHERE reconcile_partial_id = %s''', (partner_info[2],))
                    date = self.cr.fetchall()
                    partial = False
                    if 'BETWEEN' in dates_query:
                        partial = date and args_list[-3] <= date[0][0] <= args_list[-2]
                    elif '>=' in dates_query:
                        partial = date and date[0][0] >= form[str(i)]['start']
                    else:
                        partial = date and date[0][0] <= form[str(i)]['stop']
                        print'partialpartialpartial',partial
                    if partial:
                        # partial reconcilation
                        limit_date = 'COALESCE(l.date_maturity,l.date) %s %%s' % ('<=' if self.direction_selection == 'past' else '>=',)
                        print'limit_datelimit_datelimit_date',limit_date
                        self.cr.execute('''SELECT SUM(l.debit-l.credit)
                                           FROM account_move_line AS l, account_move AS am
                                           WHERE l.move_id = am.id AND am.state in %s
                                           AND l.reconcile_partial_id = %s
                                           AND ''' + limit_date, (tuple(move_state), partner_info[2], self.date_from))
                        unreconciled_amount = self.cr.fetchall()
                        print'unreconciled_amount',unreconciled_amount
                        self.cr.execute('''SELECT l.partner_id as id ,aj.code as code ,ai.date_invoice as date,(l.debit-l.credit) as amount,l.ref as journal
                                           FROM account_move_line AS l, account_move AS am
                                           JOIN account_journal AS aj ON(aj.id=am.journal_id)
                                           JOIN account_invoice as ai ON (ai.move_id=am.id)
                                           WHERE l.move_id = am.id AND am.state in %s
                                           AND l.reconcile_partial_id = %s
                                           AND ''' + limit_date, (tuple(move_state), partner_info[2], self.date_from))
                        amount = self.cr.dictfetchall()
                        print'amount',amount
                        if amount != []:
                            amount[0]['amount']= unreconciled_amount[0][0]
                            print'amount',amount
                            hope=(amount[0]['id'],amount[0]['code'],amount[0]['date'],amount[0]['amount'],amount[0]['journal'])
                            info.append([hope])
                        partners_amount[partner_info[0]] += unreconciled_amount[0][0]
                else:
                    partners_amount[partner_info[0]] += partner_info[1]
                    print partner_info
                    info.append([(partner_info[0],partner_info[4],partner_info[3],partner_info[1],partner_info[5])])
                    
            history.append(partners_amount)
        poppy=[]
        part_list=[]
        test=[]
        for i in another:
            if i !=[]:
                 poppy.append(i)
                 for j in i:
                      if j[2] == None:
                          print j
                          part_list.append(j[0])
        my=[]
        for j in poppy:
            data = sorted(j, key=itemgetter(0))
            a = {k: list(v) for k, v in groupby(data, key=itemgetter(0))}
            my.append(a)
        partss=list(set(part_list))  
        for i in my:
            for j in partss:                
                if i.has_key(j):
                    if  len(i[j]) > 1:
                        for k in i[j]:
                             if k[2] == None:
                                 test.append(k)
                    elif len(i[j]) == 1:
                        if i[j][0][4] != 'SAJ' and i[j][0][2] == None:
                            test.append(i[j][0])                        
        dell = sorted(test, key=itemgetter(0))
        adell = {k: list(v) for k, v in groupby(dell, key=itemgetter(0))}  
        for key,value in adell.iteritems():
            if len(value) > 1:
                add=[]                
                for jj in value:
                     print jj[0]  
                     add.append(jj[1])                  
                print add
                for j in value:                         
                    if j[4] == 'SAJ':
                        h=(j[0],j[4],j[3],sum(add),j[5])     
                        info.append([h])     
        for i in partner_ids:
            if i not in partnerID:
                print 'IDDDDDDDDDDDDDDDDDD',i
                self.cr.execute('SELECT l.partner_id,aj.code,ai.date_due,(l.debit-l.credit),l.ref\
                            FROM account_move_line AS l, account_account, account_move am \
                            JOIN account_journal AS aj ON(aj.id=am.journal_id)\
                            JOIN account_invoice as ai ON (ai.move_id=am.id)\
                            WHERE (l.account_id = account_account.id) AND (l.move_id=am.id) \
                            AND (am.state IN %s)\
                            AND (account_account.type IN %s)\
                            AND (l.partner_id = %s)\
                            AND ((l.reconcile_id IS NULL)\
                            OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                            AND ' + self.query + '\
                            AND account_account.active\
                            AND (l.date <= %s)\
                            GROUP BY l.partner_id,aj.code,ai.date_due,l.debit,l.credit,l.ref', (tuple(move_state), tuple(self.ACCOUNT_TYPE), i, self.date_from, self.date_from,))
                t = self.cr.fetchall()
                info.append(t)
        print'INFFFFFFFFFOOOOOOOOOOOOOOOO',info
        my_res=[]
        for j in info:
            data = sorted(j, key=itemgetter(0,1))
            a = {k: list(v) for k, v in groupby(data, key=itemgetter(0,1))}
            my_res.append(a)
        lol=[]
        print'MY_RES',my_res
        for i in sorted(my_res):
             count=0.0
             for key,value in i.iteritems():
                 if key[1] != 'SAJ':
                      for val in value:
                          count+=val[3]
                 elif key[1] == 'SAJ':
                      for val in value:
                          print (val[3] + count)
                          TODAY = datetime.strptime(self.date_from, '%Y-%m-%d')
                          DAY = datetime.strptime(val[2], '%Y-%m-%d')
                          AGE=DAY - TODAY                        
                          pop=({'partner_id':val[0],'code':val[1],'dates':val[2],'amt':(val[3]+count),'journal':val[4],'age':abs(AGE.days)+1})
                          lol.append(pop)
                 #~ elif key[1] == 'SAJ' and key[0]!=v:
                      #~ for val in value:
                          #~ print'vaaaaaaaaaaaaaaaaaaaaaa',val
                          #~ print (val[3] + count)
                          #~ TODAY = datetime.strptime(self.date_from, '%Y-%m-%d')
                          #~ DAY = datetime.strptime(val[2], '%Y-%m-%d')
                          #~ AGE=DAY - TODAY                        
                          #~ pop=({'partner_id':val[0],'code':val[1],'dates':val[2],'amt':(val[3]+count),'journal':val[4],'age':abs(AGE.days)})
                          #~ lol.append(pop) 
        seen = set()
        new_l = []
        for d in lol:
            t = tuple(d.items())
            if t not in seen:
                seen.add(t)
                new_l.append(d)
        print'new_l',new_l
        journal_list=[]
        for i in new_l:
              journal_list.append(i['journal'])
        journal=list(set(journal_list))

        g={}
        new_g=[]
        lols=sorted(new_l,key=itemgetter('journal'))
        for key,value in itertools.groupby(lols,key=itemgetter('journal')):
            for i in value:
                 g.setdefault(key, []).append(i)
        for i in journal:
            if len(g.get(i)) == 1:
                new_g.append(g.get(i)[0])
            elif  len(g.get(i)) > 1:
                k=[]
                k.append(g.get(i)[0])
                amount=[]
                for h in g.get(i):
                    amount.append(h['amt'])
                k[0]['amt']=min(amount)   
                new_g.append(k[0])
        v={}
        lols=sorted(new_g,key=itemgetter('partner_id'))
        for key,value in itertools.groupby(lols,key=itemgetter('partner_id')):
            for i in value:
                 v.setdefault(key, []).append(i)
        l1=form['1']['name'].split('-')
        l2=form['2']['name'].split('-')
        l3=form['3']['name'].split('-')        
        l4=form['4']['name'].split('-')        
        l5=form['5']['name'].split('-')        
        print (l1,l2,l3,l4)
        for key,value in v.iteritems():
              for i in value:
                   if int(l5[0]) <=  i['age'] <= int(l5[1]):
                       i.update({'0':0.0,'1':0.0,'2':0.0,'3':0.0,'4':0.0,'5':i['amt']})               
                   elif int(l4[0]) <=  i['age'] <= int(l4[1]):
                       i.update({'0':0.0,'1':0.0,'2':0.0,'3':0.0,'4':i['amt'],'5':0.0})
                   elif int(l3[0]) <= i['age'] <= int(l3[1]):
                       i.update({'0':0.0,'1':0.0,'2':0.0,'3':i['amt'],'4':0.0,'5':0.0})
                   elif int(l2[0]) <=  i['age'] <= int(l2[1]):
                       i.update({'0':0.0,'1':0.0,'2':i['amt'],'3':0.0,'4':0.0,'5':0.0})
                   elif int(l1[0]) <= i['age'] <= int(l1[1]):
                       i.update({'0':0.0,'1':i['amt'],'2':0.0,'3':0.0,'4':0.0,'5':0.0})
                   else:  
                       i.update({'0':i['amt'],'1':0.0,'2':0.0,'3':0.0,'4':0.0,'5':0.0})
        print'V$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$V',v
        for key,value in v.iteritems():
            ad=[]
            for val in value:
                ad.append(val['amt'])
            print ad
            v[key].append({'total':sum(ad)})
        result=[]
        for partner in partners:
              values={}
              if v.has_key(partner['id']):   
                  values['name'] = partner['name']  
                  get_total=v[partner['id']].pop()
                  values['total']=get_total['total']
                  values['details'] =  v[partner['id']]
                  
              result.append(values)   
        res=[]
        for r in result:
            if r != {}:
                res.append(r)
        #~ for partner in partners:
            #~ values = {}
            #~ ## If choise selection is in the future
            #~ if self.direction_selection == 'future':
                #~ # Query here is replaced by one query which gets the all the partners their 'before' value
                #~ before = False
                #~ if future_past.has_key(partner['id']):
                    #~ before = [ future_past[partner['id']] ]
                    #~ print'before::::::::::::::::::::::::::::::::::',before
                    #~ print'self.total_account[6]::::::::::::::::::::::::::::::::::',self.total_account[6]
                #~ self.total_account[6] = self.total_account[6] + (before and before[0] or 0.0)
                #~ values['direction'] = before and before[0] or 0.0
            #~ elif self.direction_selection == 'past': # Changed this so people could in the future create new direction_selections
                #~ # Query here is replaced by one query which gets the all the partners their 'after' value
                #~ after = False
                #~ if future_past.has_key(partner['id']): # Making sure this partner actually was found by the query
                    #~ after = [ future_past[partner['id']] ]
#~ 
                #~ self.total_account[6] = self.total_account[6] + (after and after[0] or 0.0)
                #~ values['direction'] = after and after[0] or 0.0
#~ 
            #~ for i in range(5):
                #~ during = False
                #~ if history[i].has_key(partner['id']):
                    #~ during = [ history[i][partner['id']] ]
                #~ # Ajout du compteur
                #~ print'self.total_account[(i)]self.total_account[(i)]',self.total_account[(i)]
                #~ print'duringduringduringduring',during
                #~ self.total_account[(i)] = self.total_account[(i)] + (during and during[0] or 0)
                #~ values[str(i)] = during and during[0] or 0.0
            #~ print'valuesvaluesvaluesvaluesvalues',values
            #~ total = False
            #~ if totals.has_key( partner['id'] ):
                #~ total = [ totals[partner['id']] ]
            #~ values['total'] = total and total[0] or 0.0
            #~ ## Add for total
            #~ self.total_account[(i+1)] = self.total_account[(i+1)] + (total and total[0] or 0.0)
            #~ values['name'] = partner['name']
            #~ res.append(values)
#~ 
        #~ total = 0.0
        #~ totals = {}
        #~ for r in res:
            #~ total += float(r['total'] or 0.0)
            #~ for i in range(5)+['direction']:
                #~ totals.setdefault(str(i), 0.0)
                #~ totals[str(i)] += float(r[str(i)] or 0.0)
        return res

    def _get_lines_with_out_partner(self, form):
        res = []
        move_state = ['draft','posted']
        if self.target_move == 'posted':
            move_state = ['posted']

        ## mise a 0 du total
        for i in range(7):
            self.total_account.append(0)
        totals = {}
        self.cr.execute('SELECT SUM(l.debit-l.credit) \
                    FROM account_move_line AS l, account_account, account_move am \
                    WHERE (l.account_id = account_account.id) AND (l.move_id=am.id)\
                    AND (am.state IN %s)\
                    AND (l.partner_id IS NULL)\
                    AND (account_account.type IN %s)\
                    AND ((l.reconcile_id IS NULL) \
                    OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                    AND ' + self.query + '\
                    AND (l.date <= %s)\
                    AND account_account.active ',(tuple(move_state), tuple(self.ACCOUNT_TYPE), self.date_from, self.date_from,))
        t = self.cr.fetchall()
        for i in t:
            totals['Unknown Partner'] = i[0]
        future_past = {}
        if self.direction_selection == 'future':
            self.cr.execute('SELECT SUM(l.debit-l.credit) \
                        FROM account_move_line AS l, account_account, account_move am\
                        WHERE (l.account_id=account_account.id) AND (l.move_id=am.id)\
                        AND (am.state IN %s)\
                        AND (l.partner_id IS NULL)\
                        AND (account_account.type IN %s)\
                        AND (COALESCE(l.date_maturity, l.date) < %s)\
                        AND ((l.reconcile_id IS NULL)\
                        OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                        AND '+ self.query + '\
                        AND account_account.active ', (tuple(move_state), tuple(self.ACCOUNT_TYPE), self.date_from, self.date_from))
            t = self.cr.fetchall()
            for i in t:
                future_past['Unknown Partner'] = i[0]
        elif self.direction_selection == 'past': # Using elif so people could extend without this breaking
            self.cr.execute('SELECT SUM(l.debit-l.credit) \
                    FROM account_move_line AS l, account_account, account_move am \
                    WHERE (l.account_id=account_account.id) AND (l.move_id=am.id)\
                        AND (am.state IN %s)\
                        AND (l.partner_id IS NULL)\
                        AND (account_account.type IN %s)\
                        AND (COALESCE(l.date_maturity,l.date) > %s)\
                        AND ((l.reconcile_id IS NULL)\
                        OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                        AND '+ self.query + '\
                        AND account_account.active ', (tuple(move_state), tuple(self.ACCOUNT_TYPE), self.date_from, self.date_from))
            t = self.cr.fetchall()
            for i in t:
                future_past['Unknown Partner'] = i[0]
        history = []

        for i in range(5):
            args_list = (tuple(move_state), tuple(self.ACCOUNT_TYPE), self.date_from,)
            dates_query = '(COALESCE(l.date_maturity,l.date)'
            if form[str(i)]['start'] and form[str(i)]['stop']:
                dates_query += ' BETWEEN %s AND %s)'
                args_list += (form[str(i)]['start'], form[str(i)]['stop'])
            elif form[str(i)]['start']:
                dates_query += ' > %s)'
                args_list += (form[str(i)]['start'],)
            else:
                dates_query += ' < %s)'
                args_list += (form[str(i)]['stop'],)
            args_list += (self.date_from,)
            self.cr.execute('SELECT SUM(l.debit-l.credit)\
                    FROM account_move_line AS l, account_account, account_move am \
                    WHERE (l.account_id = account_account.id) AND (l.move_id=am.id)\
                        AND (am.state IN %s)\
                        AND (account_account.type IN %s)\
                        AND (l.partner_id IS NULL)\
                        AND ((l.reconcile_id IS NULL)\
                        OR (l.reconcile_id IN (SELECT recon.id FROM account_move_reconcile AS recon WHERE recon.create_date > %s AND not recon.opening_reconciliation)))\
                        AND '+ self.query + '\
                        AND account_account.active\
                        AND ' + dates_query + '\
                    AND (l.date <= %s)\
                    GROUP BY l.partner_id', args_list)
            t = self.cr.fetchall()
            d = {}
            for i in t:
                d['Unknown Partner'] = i[0]
            history.append(d)

        values = {}
        if self.direction_selection == 'future':
            before = False
            if future_past.has_key('Unknown Partner'):
                before = [ future_past['Unknown Partner'] ]
            self.total_account[6] = self.total_account[6] + (before and before[0] or 0.0)
            values['direction'] = before and before[0] or 0.0
        elif self.direction_selection == 'past':
            after = False
            if future_past.has_key('Unknown Partner'):
                after = [ future_past['Unknown Partner'] ]
            self.total_account[6] = self.total_account[6] + (after and after[0] or 0.0)
            values['direction'] = after and after[0] or 0.0

        for i in range(5):
            during = False
            if history[i].has_key('Unknown Partner'):
                during = [ history[i]['Unknown Partner'] ]
            self.total_account[(i)] = self.total_account[(i)] + (during and during[0] or 0)
            values[str(i)] = during and during[0] or 0.0

        total = False
        if totals.has_key( 'Unknown Partner' ):
            total = [ totals['Unknown Partner'] ]
        values['total'] = total and total[0] or 0.0
        ## Add for total
        self.total_account[(i+1)] = self.total_account[(i+1)] + (total and total[0] or 0.0)
        values['name'] = 'Unknown Partner'

        if values['total']:
            res.append(values)

        total = 0.0
        totals = {}
        for r in res:
            total += float(r['total'] or 0.0)
            for i in range(5)+['direction']:
                totals.setdefault(str(i), 0.0)
                totals[str(i)] += float(r[str(i)] or 0.0)
        return res

    def _get_total(self,pos):
        print'posssssssssssssssssssssssss',pos
        period = self.total_account[int(pos)]
        return period or 0.0

    def _get_direction(self,pos):
        period = self.total_account[int(pos)]
        return period or 0.0

    def _get_for_period(self,pos):
        period = self.total_account[int(pos)]
        return period or 0.0

    def _get_partners(self,data):
        # TODO: deprecated, to remove in trunk
        if data['form']['result_selection'] == 'customer':
            return self._translate('Receivable Accounts')
        elif data['form']['result_selection'] == 'supplier':
            return self._translate('Payable Accounts')
        elif data['form']['result_selection'] == 'customer_supplier':
            return self._translate('Receivable and Payable Accounts')
        return ''


class report_fnetagedpartnerbalance(osv.AbstractModel):
    _name = 'report.fnet_new_age.report_fnetagedpartnerbalance'
    _inherit = 'report.abstract_report'
    _template = 'fnet_new_age.report_fnetagedpartnerbalance'
    _wrapped_report_class = fnet_aged_partner_report

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
