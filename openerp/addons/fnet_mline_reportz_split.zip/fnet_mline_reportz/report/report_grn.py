from openerp import api, models
import datetime
import math
from openerp.exceptions import ValidationError,Warning
                                                                                  
                                                                                                                          
class ParticularReport(models.AbstractModel):
    _name = 'report.fnet_mline_reportz.grn'
                
    def min_date(self,obj):     
        if obj:
            leave_form = self.env['stock.picking'].search([('origin','=',obj.origin)])
            date_time = datetime.datetime.strptime((leave_form[0].date), '%Y-%m-%d %H:%M:%S').strftime('%d-%m-%Y')                                                                        
            return date_time 
    
    def move_line(self,obj):
        count=0
        lol = lambda lst, sz: [lst[i:i+sz] for i in range(0, len(lst), sz)]
        if obj:
            self.env.cr.execute(" select sm.product_uom_qty as product, pt.description as name, pp.part_no, pp.make_no "\
                            " from stock_move sm join product_product pp on  "\
                            " (pp.id=sm.product_id) join product_template pt "\
                            " on (pt.id=pp.product_tmpl_id) where sm.picking_id=%s" % (str(obj.id)))
        line_list = [i for i in self.env.cr.dictfetchall()]
        desc_len=[]
        for i in line_list:
            txt=i['name'].split('\n')
            desc_len.append(len(txt))               
        print'SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS',sum(desc_len)
        if sum(desc_len) <= 15:
            count= count + 1
        elif sum(desc_len) > 15:
            count= math.ceil(float(count + sum(desc_len))/float(15.0))
        value=[]
        if count <= 1:
            value.append(0)
        else:
            for val in range(0,int(count)):
                value.append(val)
        return value
    
    def get_move_line(self,obj,val):
        if obj:
            self.env.cr.execute(" select sm.product_uom_qty as product, pt.description as name, pp.part_no, pp.make_no "\
                            " from stock_move sm join product_product pp on  "\
                            " (pp.id=sm.product_id) join product_template pt "\
                            " on (pt.id=pp.product_tmpl_id) where sm.picking_id=%s" % (str(obj.id)))
        line_list = [i for i in self.env.cr.dictfetchall()]
        desc=[]
        lol = lambda lst, sz: [lst[i:i+sz] for i in range(0, len(lst), sz)]
        final=[]
        for i in line_list:
            txt=i['name'].split('\n')
            desc.append({'prod_desc':txt,'prod_qty':i['product']})
        for i in desc:
            lop=[]
            lop=lol(i['prod_desc'],15)
            bob=[]
            for j in range(len(lop)):
                  if j == 0:
                      for k in lop[j]:
                           bob.append({'desc':k,'qty':0})
                      bob[0]['qty']=i['prod_qty']
                  else:
                      for k in lop[j]:
                           bob.append({'desc':k,'qty':0})
                  final.extend(bob)              
        print'bbbbbbbbbbbbbbbbbbbbbb',final 
        limit= 15
        offset= val * 15
        print'limiiiiiiiiiiiiiiiiiiiiiiiiiiiii',val
        print'limiiiiiiiiiiiiiiiiiiiiiiiiiiiii',final[limit:offset]
        #~ 
        #~ count=0
        #~ if val < 1:
            #~ count=val+1
        #~ elif val >= 1:
            #~ count= val*15 + 1
        #~ for val in line_list:
            #~ val['serial_no']=count
            #~ count=count+1
        #~ if line_list:
        return final[limit:offset]
               
    @api.multi
    def render_html(self, data=None):
        report_obj = self.env['report']
        report = report_obj._get_report_from_name('fnet_mline_reportz.grn')
        stock_pick=self.env['stock.picking'].search([('id','=',self.id)])
        sale_order=self.env['sale.order'].search([('name','=',stock_pick.origin)])
        docargs = {
            'doc_ids': stock_pick,
            'sale':sale_order,
            'doc_model': report.model,
            'docs': self,
        }
        if stock_pick.picking_type_id.code=='incoming':
            return report_obj.render('fnet_mline_reportz.grn', docargs)
        else:
            raise ValidationError('Please choose the valid report!')
 
    
 
