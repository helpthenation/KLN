from openerp import api, models
import datetime
import math
from openerp.exceptions import ValidationError,Warning
                                                                                  
                                                                                                                          
class ParticularReport(models.AbstractModel):
    _name = 'report.fnet_mline_reportz.del_note'
                
    def min_date(self,obj):     
        if obj:
            leave_form = self.env['stock.picking'].search([('origin','=',obj.origin)])
            date_time = datetime.datetime.strptime((leave_form[0].date), '%Y-%m-%d %H:%M:%S').strftime('%d-%m-%Y')                                                                        
            return date_time 
    
    def move_line(self,obj):
        count=0
        if obj:
            self.env.cr.execute(" select count(id) as value from stock_move "\
                                "where picking_id= %s" % (str(obj.id)))
        line_list = [i for i in self.env.cr.dictfetchall()]
        if line_list[0]['value'] <= 2:
            count= count + 1
        elif line_list[0]['value'] > 2:
            count= math.ceil(float(count + line_list[0]['value'])/float(2.0))
        value=[]
        if count <= 1:
            value.append(0)
        else:
            for val in range(0,int(count)):
                value.append(val)
        return value
    
    def get_move_line(self,obj,val):
        if obj:
            limit= 2
            offset= val * 2
            self.env.cr.execute(" select sm.product_uom_qty as product, pt.description as name, pp.part_no, pp.make_no "\
                            " from stock_move sm join product_product pp on  "\
                            " (pp.id=sm.product_id) join product_template pt "\
                            " on (pt.id=pp.product_tmpl_id) where sm.picking_id=%s limit %s offset %s" % (str(obj.id),str(limit),str(offset)))
        line_list = [i for i in self.env.cr.dictfetchall()]
        count=0
        if val < 1:
            count=val+1
        elif val >= 1:
            count= val*2 + 1
        for val in line_list:
            val['serial_no']=count
            count=count+1
        if line_list:
            return line_list
               
    @api.multi
    def render_html(self, data=None):
        report_obj = self.env['report']
        report = report_obj._get_report_from_name('fnet_mline_reportz.del_note')
        stock_pick=self.env['stock.picking'].search([('id','=',self.id)])
        sale_order=self.env['sale.order'].search([('name','=',stock_pick.origin)])
        docargs = {
            'doc_ids': stock_pick,
            'sale':sale_order,
            'doc_model': report.model,
            'docs': self,
        }
        if stock_pick.picking_type_id.code=='outgoing':
            return report_obj.render('fnet_mline_reportz.del_note', docargs)
        else:
            raise ValidationError('Please choose the valid report!')
 
    
 
