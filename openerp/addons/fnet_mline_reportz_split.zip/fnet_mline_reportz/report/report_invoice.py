#-*- coding:utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2009 Tiny SPRL (<http://tiny.be>). All Rights Reserved
#    d$
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
import locale
from openerp.osv import osv
from openerp.report import report_sxw
import math
from datetime import datetime
class invoice_report1(report_sxw.rml_parse):
    
    counter=0
    def __init__(self, cr, uid, name, context):
        if context is None:
            context = {}
        super(invoice_report1, self).__init__(cr, uid, name, context)
        self.localcontext.update({
                'get_dc_number': self._get_dc_number,
                'invoice_line': self._invoice_line,
                'get_invoice_line': self._get_invoice_line,
                'numtowords': self._numtowords,
                'get_amount': self._get_amount,
                'get_job_no': self._get_job_no,
                'get_int': self._get_int,
                'get_date': self._get_date,
        })
        self.context = context
        
        
    def _get_date(self,val):
        if val:
            return datetime.strptime(str(val), '%Y-%m-%d').strftime('%d-%m-%Y')
            
            
    def _get_int(self,val):
        if val:
            return int(val)
            
    def _get_job_no(self,val):
        if val:
            sale_obj = self.pool['sale.order']
            sale_obj_id = sale_obj.search(self.cr, self.uid,[('name','=',val)], context=self.context)
            if sale_obj_id:
                sale_re=sale_obj.browse(self.cr,self.uid,sale_obj_id)
                return sale_re.job_id
        
    def _get_amount(self,val):
        count=0
        ids = self.context.get('active_ids')
        inv_obj = self.pool['account.invoice']
        inv_br_obj = inv_obj.browse(self.cr, self.uid, ids, context=self.context)
        if inv_br_obj:
            self.cr.execute(" select count(id) as value from account_invoice_line "\
                                "where invoice_id= %s" % (str(inv_br_obj.id)))
        line_list = [i for i in self.cr.dictfetchall()]
        if line_list[0]['value']:
            count= math.ceil(float(count + line_list[0]['value'])/float(4.0))
        
        if (count-1) == val:
            val='{0:.2f}'.format(inv_br_obj.amount_total)
            amount='{:20,.2f}'.format(float(val))
            return amount
        else:
            return "Continued"
        
    def _numtowords(self,num,join=True):
        '''words = {} convert an integer number into words'''
        units = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine']
        teens = ['','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen', \
                 'Seventeen','Eighteen','Nineteen']
        tens = ['','Ten','Twenty','Thirty','Forty','Fifty','Sixty','Seventy', \
                'Eighty','Ninety']
        thousands = ['','Thousand','Million','Billion','Trillion','Quadrillion', \
                     'Quintillion','Sextillion','Septillion','oOtillion', \
                     'Nonillion','Decillion','Undecillion','Duodecillion', \
                     'Tredecillion','Quattuordecillion','Sexdecillion', \
                     'Septendecillion','Octodecillion','Novemdecillion', \
                     'Vigintillion']
        words = []
        num=round(num)
        if num==0: words.append('zero')
        else:
            numStr = '%d'%num
            numStrLen = len(numStr)
            groups = (numStrLen+2)/3
            numStr = numStr.zfill(groups*3)
            for i in range(0,groups*3,3):
                h,t,u = int(numStr[i]),int(numStr[i+1]),int(numStr[i+2])
                g = groups-(i/3+1)
                if h>=1:
                    words.append(units[h])
                    words.append('hundred')
                if t>1:
                    words.append(tens[t])
                    if u>=1: words.append(units[u])
                elif t==1:
                    if u>=1: words.append(teens[u])
                    else: words.append(tens[t])
                else:
                    if u>=1: words.append(units[u])
                if (g>=1) and ((h+t+u)>0): words.append(thousands[g])
        if words:
           words.append( " Only")
        if join: return ' '.join(words)
        return words 
          
    def _invoice_line(self):
        count=0
        ids = self.context.get('active_ids')
        inv_obj = self.pool['account.invoice']
        inv_br_obj = inv_obj.browse(self.cr, self.uid, ids, context=self.context)
        if inv_br_obj:
            self.cr.execute(" select count(id) as value from account_invoice_line "\
                                "where invoice_id= %s" % (str(inv_br_obj.id)))
        line_list = [i for i in self.cr.dictfetchall()]
        if line_list[0]['value'] <= 4:
            count= count + 1
        elif line_list[0]['value'] > 4:
            count= math.ceil(float(count + line_list[0]['value'])/float(4.0))
        value=[]
        if count <= 1:
            value.append(0)
        else:
            for val in range(0,int(count)):
                value.append(val)
        return value
        
        
    def _get_invoice_line(self,val):
        ids = self.context.get('active_ids')
        inv_obj = self.pool['account.invoice']
        inv_br_obj = inv_obj.browse(self.cr, self.uid, ids, context=self.context)
        if inv_br_obj:
            limit= 4
            offset= val * 4
            self.cr.execute(" select ail.id,ail.name as description,pt.make_no as make_no,pt.part_no as part_no,  "\
                            " pu.name as uos_id ,ail.quantity, ail.price_unit, "\
                            " ail.price_subtotal from account_invoice_line ail "\
                            "  join product_uom pu on (pu.id=ail.uos_id) left join  "\
                            " product_template pt on (pt.id= ail.product_id) "\
                            "where ail.invoice_id=%s limit %s offset %s" % (str(inv_br_obj.id),str(limit),str(offset)))
        line_list = [i for i in self.cr.dictfetchall()]
        count=0
        if val < 1:
            count=val+1
        elif val >= 1:
            count= val*4 + 1
        for val in line_list:
            val['serial_no']=count
            count=count+1
        if line_list:
            return line_list
        
        
        
        
    def _get_dc_number(self):
        ids = self.context.get('active_ids')
        inv_obj = self.pool['account.invoice']
        inv_br_obj = inv_obj.browse(self.cr, self.uid, ids, context=self.context)
        stock_move=self.pool['stock.move']
        stock_id=stock_move.search(self.cr,self.uid,[('origin','=',inv_br_obj.origin)])
        stock_move_obj=stock_move.browse(self.cr,self.uid,stock_id,context=self.context)
        val=''
        for rec in stock_move_obj:
            val= rec.picking_id.name + ','
        return val
    


class wrapped_report_invoice(osv.AbstractModel):
    _name = 'report.fnet_mline_reportz.report_invoice'
    _inherit = 'report.abstract_report'
    _template = 'fnet_mline_reportz.report_invoice'
    _wrapped_report_class = invoice_report1

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
