# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2008 Zikzakmedia S.L. (http://zikzakmedia.com)
#                       Jordi Esteve <jesteve@zikzakmedia.com>
#    Copyright (C) 2011 Domsense srl (<http://www.domsense.com>)
#    Copyright (C) 2011-2013 Agile Business Group sagl
#    (<http://www.agilebg.com>)
#    Ported to Odoo by Andrea Cometa <info@andreacometa.it>
#    Ported to v8 API by Eneko Lacunza <elacunza@binovo.es>
#    Copyright (c) 2015 Serv. Tecnol. Avanzados - Pedro M. Baeza
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published
#    by the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from openerp import models, fields, api
from openerp.exceptions import except_orm, Warning, RedirectWarning
from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import datetime
from datetime import date
from dateutil.relativedelta import relativedelta

class update_pricelist(models.Model):
    """
    This wizard will submit the all the selected Sale Target
    """

    _name = "update.pricelist"
    _description = "Submit the pricelist"

    #~ def _get_default_company(self, cr, uid, context=None):
        #~ company_id = self.pool.get('res.users')._get_company(cr, uid, context=context)
        #~ if not company_id:
            #~ raise osv.except_osv(_('Error!'), _('There is no default company for the current user!'))
        #~ return company_id  
          
       
    date=fields.Date('Date',required=True)
    prod_categ_id=fields.Many2one('product.category', 'Product Category', required=True)
    product_entry_line=fields.One2many('product.entry.line', 'prod_upadate_id', 'Product Lines')
    company_id=fields.Many2one('res.company','Company')

    #~ _defaults = {
        #~ 'company_id': _get_default_company,
        #~ 'date': datetime.now().strftime("%Y-%m-%d"),
        #~ }    

    @api.model
    def create(self, vals):
        rec_id=super(update_pricelist, self).create(vals)
        if vals.get('prod_categ_id'):            
            print'RECCCCCCCCCCC',rec_id
            cate = self.env['product.category'].browse(vals.get('prod_categ_id'))
            self.env.cr.execute("""select 
                              pp.id as prod,
                              pt.uom_id as uom,
                              pt.list_price as sale_pr,
                              pt.mrp_price as mrp ,
                              pt.purchase_discount as purchase_discount ,
                              pt.discount_price as discount_price 
                        from product_template pt
                        join product_product pp on (pp.product_tmpl_id = pt.id)
                        where pt.categ_id = '%s' and pt.company_id = '%s' and pt.type != 'service'
                            order by 2 """ % (vals.get('prod_categ_id'), cate.company_id.id))
            line_list = [i for i in self.env.cr.dictfetchall()]
            if rec_id:
				for fid in line_list:
				   new_rec=self.env['product.entry.line'].create({"prod_upadate_id":rec_id.id,"product_id":fid['prod'], "uom_id":fid['uom'],"mrp_price":fid['mrp'],"list_price":fid['sale_pr'],
					"purchase_discount":fid['purchase_discount'],'discount_price':fid['discount_price']})
        return rec_id               
        
    @api.multi
    @api.onchange('prod_categ_id')
    def onchange_prod_categ_id(self):
        #~ result = onchange_prod_categ_id(cr, uid, ids,prod_categ_id=prod_categ_id, company_id=company_id, context=context)
        print'CCCCCCCCC',self._origin.id
        #~ if context.get('company_id', False):
            #~ company_id = context['company_id']
        #~ else:
            #~ company_id = self.pool.get('res.users').browse(cr, uid, ids, context=context).company_id.id
        #~ company_id = company_id if company_id is not None else context.get('company_id', False)
        #~ result = {}
        #~ rec_id=self.create({'prod_categ_id':self.prod_categ_id,'date':'2017-12-23'})
        list_of_dict=[]
        if self.prod_categ_id:
            rec_id=self._origin.id
            print'RECCCCCCCCCCC',rec_id
            cate = self.env['product.category'].browse(self.prod_categ_id.id,)
            self.env.cr.execute("""select 
                              pp.id as prod,
                              pt.uom_id as uom,
                              pt.list_price as sale_pr,
                              pt.mrp_price as mrp ,
                              pt.purchase_discount as purchase_discount ,
                              pt.discount_price as discount_price 
                        from product_template pt
                        join product_product pp on (pp.product_tmpl_id = pt.id)
                        where pt.categ_id = '%s' and pt.company_id = '%s' and pt.type != 'service'
                            order by 2 """ % (self.prod_categ_id.id, cate.company_id.id))
            line_list = [i for i in self.env.cr.dictfetchall()]
            for fid in line_list:
               new_rec=self.env['product.entry.line'].create({"prod_upadate_id":rec_id,"product_id":fid['prod'], "uom_id":fid['uom'],"mrp_price":fid['mrp'],"list_price":fid['sale_pr'],
                "purchase_discount":fid['purchase_discount'],'discount_price':fid['discount_price']})
               #~ list_of_dict.append(new_rec) 
            #~ result['value'].update({'product_entry_line':list_of_dict,})
            #~ return {'value': {'product_entry_line': list_of_dict}}
            #~ return result
    #~ def update(self, cr, uid, ids, context=None):
        #~ print'################################',context
        #~ obj = self.browse(cr, uid, ids)
        #~ for rec in obj.product_entry_line:
            #~ print'DDDDDDDDDDDDDDDDDDDDDDDDD',rec.product_id.product_tmpl_id.id
            #~ cr.execute("""update product_template set mrp_price=%d,purchase_discount=%d,discount_price=%d,list_price=%d
            #~ where id=%d"""%(rec.mrp_price,rec.purchase_discount,rec.discount_price,rec.list_price,rec.product_id.product_tmpl_id.id))            
            #~ cr.execute("""update product_product set mrp_price=%d,purchase_discount=%d,discount_price=%d
            #~ where id=%d"""%(rec.mrp_price,rec.purchase_discount,rec.discount_price,rec.product_id.id))            
          
            
class product_entry_line(models.Model):
    _name = 'product.entry.line'
    
    #~ def _get_default_company(self, cr, uid, context=None):
        #~ company_id = self.pool.get('res.users')._get_company(cr, uid, context=context)
        #~ if not company_id:
            #~ raise osv.except_osv(_('Error!'), _('There is no default company for the current user!'))
        #~ return company_id
        

    prod_upadate_id=fields.Many2one('update.pricelist', 'Sale Entry')
    product_id=fields.Many2one('product.product', 'Product', required=True, readonly=True)
    uom_id=fields.Many2one('product.uom', 'Product UOM', required=True, readonly=True)
    mrp_price=fields.Float('MRP Price')
    list_price=fields.Float('Sale Price')
    purchase_discount=fields.Float('Purchase Discount')
    discount_price=fields.Float('Sale Discount')


    #~ _defaults = {
        #~ 'company_id': _get_default_company,
        #~ }
