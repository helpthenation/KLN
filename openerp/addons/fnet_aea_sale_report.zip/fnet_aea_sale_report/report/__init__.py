#-*- coding:utf-8 -*-

##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2009 Tiny SPRL (<http://tiny.be>). All Rights Reserved
#    d$
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import report_sale_return
import report_sale_register
import report_purchase_register
import report_stock_ledger
import report_purchase_register_consolidated
import report_sale_register_consolidated
import report_party_sale_wise_summary
import report_sale_summary
import report_sale_summary_month_wise
import report_credit_note_summary
import report_debtors_closing_balance
import report_product_wise_sales_summary
import report_bank_book
import report_salary_register,report_sale_register_prod,report_sale_return_prod
#~ import report_consolidated_sales

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
