# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import time
import calendar
from datetime import datetime
from datetime import timedelta
from dateutil import relativedelta
from datetime import *; from dateutil.relativedelta import *
from openerp.osv import fields, osv
from openerp.tools.translate import _
from dateutil.rrule import rrule, DAILY
from dateutil.parser import parse
from openerp.exceptions import ValidationError,Warning

class hr_attendance_new(osv.osv):
    _name = 'hr.attendance.new'
    _description = 'Hr attendance customized module'

    _columns = {
        'employee_id': fields.many2one('hr.employee', "Employee", select=True),
        'name':fields.many2one('hr.department', 'Department Name'),
        'emp_code':fields.char('Employee Code'),
        'user_id':fields.char('User Id'),
        'date':fields.date('Date', required=True),
        'sign_in':fields.float('Sign In (24 Hours)', required=True),
        'sign_out':fields.float('Sign Out (24 Hours)',required=True),
        'work_done_in_day':fields.char('Work Done in Day (Hour)', required=True),
        'remark':fields.text('Remark'),
        'status':fields.char('Status'),
        'validated':fields.char('Validate'),
    }

    _defaults = {
        'date':datetime.now(),
        'validated':'No',
    }

    def create(self, cr, uid, values, context=None):
        """ Override to avoid automatic logging of creation
            SELECT date_from, date_to
            FROM hr_holidays
            WHERE '2017-10-10' between date_from::date and date_to::date"""
        if context is None:
            context = {}
        employee_id = values.get('employee_id', False)
        if employee_id:
            emp_obj = self.pool.get('hr.employee').browse(cr, uid, employee_id, context = context)
            if emp_obj.department_id.id:
                values.update({'name':emp_obj.department_id.id})
            if  emp_obj.emp_code:
                values.update({'emp_code':emp_obj.emp_code})
        det = values.get('date')
        year_obj, month_obj, day = (int(x) for x in det.split('-'))
        no_of_fridays=len([1 for i in calendar.monthcalendar(year_obj,month_obj) if i[4] != 0])
        leave_date=[]
        print'FRIDAY COUNT',no_of_fridays
        cr.execute('''select date from public_holiday where to_char(date, 'MM')='%s' 
                            and to_char(date, 'YYYY')='%s' ''' % (str(month_obj).zfill(2), str(year_obj)))
        leave = cr.dictfetchall() 
        if leave:
            for i in leave:  
                leave_date.append(i['date'])
        last_present=[]
        if employee_id:
            contract=self.pool.get('hr.contract')
            contract_search=contract.search(cr, uid, [('employee_id', '=', employee_id)], context=context)
            contract_obj=contract.browse(cr, uid, contract_search[0], context=context)
            status=self.pool.get('hr.holidays.status')
            status_search=status.search(cr, uid, [('code', '=', 'VL')], context=context)
            status_obj=status.browse(cr, uid, status_search[0], context=context)    
            if  contract_obj and status_obj:
                if contract_obj.date_start <= values.get('date'):
                    cr.execute('''select hh.id as id
                           from hr_holidays hh
                           join hr_holidays_status hhs on (hhs.id = hh.holiday_status_id)
                           where hh.employee_id = '%s' and hhs.code='VL' and hh.type='add' '''%(employee_id))   
                    hol_data=cr.dictfetchone()
                    cr.execute('''select id from hr_attendance_new where employee_id = %d and  to_char(date, 'MM')='%s' 
                       and to_char(date, 'YYYY')='%s' ''' % (employee_id, str(month_obj).zfill(2), str(year_obj)))
                    is_first_day=cr.dictfetchall()   
                    if  is_first_day != []:
                        if hol_data:
                            cr.execute('''update hr_holidays set number_of_days = number_of_days+0.0822,number_of_days_temp = number_of_days+0.0822 where id=%d'''%(hol_data['id']))  
                        else:
                            vals={
                            'name':'Vacation Leave',
                            'type':'add',
                            'employee_id':employee_id,
                            'number_of_days':15,
                            'number_of_days_temp':15,
                            'holiday_type':'employee',
                            'holiday_status_id':status_obj.id
                            }
                            self.pool.get('hr.holidays').create(cr, uid, vals, context=context)
                    else:
                        #~ current_month = datetime.strptime(values.get('date'), '%Y-%m-%d')    
                        #~ LM = current_month - relativedelta(months=1)
                        #~ last_month=LM.strftime('%Y-%m-%d')    
                        #~ p_year, p_month, day = (int(x) for x in last_month.split('-'))
                        #~ num_days = calendar.monthrange(p_year, p_month)[1]
                        #~ days = [date(p_year, p_month, day) for day in range(1, num_days+1)]
                        #~ total_days=[]
                        #~ for i in days:
                             #~ dates=i.strftime("%Y-%m-%d")
                             #~ total_days.append(dates)
                        #~ cr.execute('''select date  from hr_attendance_new 
                                       #~ where employee_id = '%s' and to_char(date, 'MM')='%s' 
                                      #~ and to_char(date, 'YYYY')='%s' ''' % (employee_id, str(p_month).zfill(2), str(p_year)))
                        #~ att = cr.fetchall()  
                        #~ attend=[x[0] for x in att]
                        #~ last_present.extend(attend)  
                        #~ cr.execute('''select hh.employee_id,hh.date_from,hh.date_to from hr_holidays hh
                                       #~ join hr_holidays_status hhs on (hhs.id = hh.holiday_status_id)
                                       #~ where hh.employee_id = '%s' and hh.state='validate' 
                                       #~ and hh.type='remove' and to_char(hh.date_from, 'MM')='%s' 
                                       #~ and to_char(date_from, 'YYYY')='%s' ''' % (employee_id, str(p_month).zfill(2), str(p_year)))
                        #~ emps = cr.dictfetchall()
                        #~ if emps != []:
                            #~ for k in emps:
                                #~ start=parse(k['date_from'])
                                #~ stop=parse(k['date_to'])
                                #~ for dts in rrule(DAILY, dtstart=start, until=stop): 
                                        #~ day_dates=dts.strftime("%Y-%m-%d")
                                        #~ last_present.append(day_dates)      
                        #~ cr.execute('''select date from public_holiday where to_char(date, 'MM')='%s' 
                                            #~ and to_char(date, 'YYYY')='%s' ''' % (str(p_month).zfill(2), str(p_year)))
                        #~ leave = cr.dictfetchall() 
                        #~ if leave:
                            #~ for i in leave:  
                                #~ last_present.append(i['date'])                                                        
                        #~ not_mentioned=[]
                        #~ for i in total_days:
                            #~ if i not in last_present:
                                #~ dates=datetime.strptime(i,"%Y-%m-%d")
                                #~ dat= dates.strftime("%A")
                                #~ if dat != 'Friday':
                                      #~ not_mentioned.append(i)
                        #~ if not_mentioned != []:
                            #~ for i in not_mentioned:
                                #~ v={
                                #~ 'employee_id':employee_id,
                                #~ 'date':i
                                #~ }
                                #~ y=self.pool.get('not.mentioned.holidays').create(cr, uid, v, context=context)      
                        emp_leave=[]
                        cr.execute('''select hh.employee_id,hh.date_from,hh.date_to from hr_holidays hh
                                       join hr_holidays_status hhs on (hhs.id = hh.holiday_status_id)
                                       where hh.employee_id = '%s' and hhs.code not in ('UL','VL') and hh.state='validate' 
                                       and hh.type='remove' and to_char(hh.date_from, 'MM')='%s' 
                                       and to_char(date_from, 'YYYY')='%s' ''' % (employee_id, str(month_obj).zfill(2), str(year_obj)))
                        emps = cr.dictfetchall()
                        if emps != []:
                            for k in emps:
                                start=parse(k['date_from'])
                                stop=parse(k['date_to'])
                                for dts in rrule(DAILY, dtstart=start, until=stop):
                                    dat= dts.strftime("%A")
                                    if dat != 'Friday':
                                        day_dates=dts.strftime("%Y-%m-%d")
                                        if  day_dates not in leave_date:
                                            emp_leave.append(day_dates)
                        fri_leave=[]
                        cr.execute('''select hh.employee_id,hh.date_from,hh.date_to from hr_holidays hh
                                       join hr_holidays_status hhs on (hhs.id = hh.holiday_status_id)
                                       where hh.employee_id = '%s' and hhs.code in ('UL','VL') and hh.state='validate' 
                                       and hh.type='remove' and to_char(hh.date_from, 'MM')='%s' 
                                       and to_char(date_from, 'YYYY')='%s' ''' % (employee_id, str(month_obj).zfill(2), str(year_obj)))
                        fri = cr.dictfetchall()
                        if fri != []:
                            for k in emps:
                                start=parse(k['date_from'])
                                stop=parse(k['date_to'])
                                for dts in rrule(DAILY, dtstart=start, until=stop):
                                    dat= dts.strftime("%A")
                                    if dat == 'Friday':
                                        day_dates=dts.strftime("%Y-%m-%d")
                                        fri_leave.append(day_dates)                                        
                        val=(len(leave_date)+ (no_of_fridays - len(fri_leave))+ len(emp_leave)) * 0.0822
                        print'VVVVVVVVVVVVVVV',val
                        if hol_data:
                            cr.execute('''update hr_holidays set number_of_days = number_of_days + %d,number_of_days_temp = number_of_days+%d where id=%d'''%(val,val,hol_data['id']))  
                        else:
                            vals={
                            'name':'Vacation Leave',
                            'type':'add',
                            'employee_id':employee_id,
                            'number_of_days':15 + val,
                            'number_of_days_temp':15 + val,
                            'holiday_type':'employee',
                            'holiday_status_id':status_obj.id
                            }
                            self.pool.get('hr.holidays').create(cr, uid, vals, context=context)                          
        return super(hr_attendance_new, self).create(cr, uid, values, context=context)    
        
        
    def on_change_to_get_employee_no(self, cr, uid, ids, employee_id, context = None):
        if not employee_id:
            return False
        res = {}
        emp_obj = self.pool.get('hr.employee')
        emp_search = emp_obj.search(cr, uid,[('id', '=', employee_id)])
        emp_browse = emp_obj.browse(cr, uid, emp_search, context = context)
        res['name'] = emp_browse.department_id
        res['user_id'] = emp_browse.identification_id
        res['emp_code'] = emp_browse.emp_code
        return {'value': res}

    def on_change_work_done_in_day(self, cr, uid, ids, sign_in, sign_out, context = None):
        if not sign_in or not sign_out:
            return False
        res = {}
        print'**************************',res
        sign_in_time = str(sign_in).split('.')
        print'xxxxxxxxxxxx',sign_in
        sign_in_new = time(hour= int(sign_in_time[0]), minute=int(sign_in_time[1]))
        print'uuuuuuuuuuuuuuu',sign_in_new
        sign_out_time = str(sign_out).split('.')
        sign_out_new = time(hour= int(sign_out_time[0]), minute=int(sign_out_time[1]))
        work_done = str(datetime.strptime(str(sign_out_new), '%H:%M:%S') - datetime.strptime(str(sign_in_new), '%H:%M:%S')).split(':')
        work_done_in_day = work_done[0] +':'+ work_done[1]
        res['work_done_in_day'] = work_done_in_day
        return {'value': res}
    
    def unlink(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids,context=context)
        for i in obj:
            cr.execute('''SELECT employee_id,date_from, date_to
                FROM mline_payroll
                WHERE '%s' between date_from::date and date_to::date and employee_id=%d'''%(i.date,i.employee_id.id)) 
            validate=cr.dictfetchall()
            if validate!=[]:
                 raise osv.except_osv(_('Invalid Action!'), _('Cannot delete this attendance entry since payroll has been generated!'))
            else:
                cr.execute('''delete from hr_attendance_new where id=%d''' %(i.id))
class hr_holidays_status(osv.osv):
    _inherit='hr.holidays.status'
    
    _columns={
    'code':fields.char('Code'),
    }

class hr_holidays(osv.osv):
    _inherit='hr.holidays'
    
    _columns={
    'buffer_days':fields.float('Buffered Duration'),
    }
class not_mentioned_holidays(osv.osv):
    _name='not.mentioned.holidays'
    _columns={
    'employee_id':fields.many2one('hr.employee','Employee'),
    'date':fields.date('Date'),
    }
