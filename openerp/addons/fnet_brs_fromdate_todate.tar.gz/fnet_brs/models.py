# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright (c) 2008 Zikzakmedia S.L. (http://zikzakmedia.com)
#                       Jordi Esteve <jesteve@zikzakmedia.com>
#    Copyright (C) 2011 Domsense srl (<http://www.domsense.com>)
#    Copyright (C) 2011-2013 Agile Business Group sagl
#    (<http://www.agilebg.com>)
#    Ported to Odoo by Andrea Cometa <info@andreacometa.it>
#    Ported to v8 API by Eneko Lacunza <elacunza@binovo.es>
#    Copyright (c) 2015 Serv. Tecnol. Avanzados - Pedro M. Baeza
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published
#    by the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api


class daywise_brs_line(models.Model):
    _inherit='daywise.brs.line'
    
    reconcile = fields.Boolean(compute='_compute_invoice',
        string='Reconcile', store=True)
    reconsile_date = fields.Date(compute='_compute_invoice',
        string='Reconcile Date', store=True)

    @api.multi
    @api.depends('daywise_brs_id.stmt_id.statement_line.reconcile','daywise_brs_id.stmt_id.statement_line.reconsile_date')
    def _compute_invoice(self):
        #~ print'daywise_brs_id',self.daywise_brs_id
        test=[]
        for line in self:
            self.env.cr.execute("""SELECT   
                                                    bsl.reconcile, 
                                                    bsl.reconsile_date, 
                                                    bsl.date,
                                                    dsl.cheque,
                                                    dsl.move_id,
                                                    dsl.id
                                                    FROM 
                                                    brs_statement bs
                                                    INNER JOIN daywise_brs ds ON ds.stmt_id = bs.id  
                                                    INNER JOIN daywise_brs_line dsl ON dsl.daywise_brs_id = ds.id
                                                    INNER JOIN brs_statement_line bsl ON bsl.move_id = dsl.move_id
                                                    WHERE 
                                                    dsl.id=%d 
                                                    order by bsl.write_date::timestamp desc limit 1"""%(line.id))
            brs=self.env.cr.dictfetchone()
            if brs != None:
				if brs['reconsile_date'] != None:
					line.reconcile=brs['reconcile']
					line.reconsile_date=brs['reconsile_date']
					print'BRS_____________',brs

