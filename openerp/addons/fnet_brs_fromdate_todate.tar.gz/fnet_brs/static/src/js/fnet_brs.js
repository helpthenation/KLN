 openerp.fnet_brs = function (openerp)
{   
    openerp.web.form.widgets.add('brs_payment', 'openerp.fnet_brs.Mywidget');
    openerp.fnet_brs.Mywidget = openerp.web.form.FieldChar.extend(
        {
        template : "brs_payment",
        init: function (view, code) {
            this._super(view, code);
            console.log('loading...');
        }
    });
}

